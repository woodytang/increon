<!-- text input -->
<div <?php echo $__env->make('crud::inc.field_wrapper_attributes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> >
    <label><?php echo $field['label']; ?></label>

	
	<?php if(isset($field['value']) && count($field['value'])): ?>
    <div class="well well-sm file-preview-container">
    	<?php $__currentLoopData = $field['value']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $file_path): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    		<div class="file-preview">
	    		<a target="_blank" href="<?php echo e(isset($field['disk'])?asset(\Storage::disk($field['disk'])->url($file_path)):asset($file_path)); ?>"><?php echo e($file_path); ?></a>
		    	<a id="<?php echo e($field['name']); ?>_<?php echo e($key); ?>_clear_button" href="#" class="btn btn-default btn-xs pull-right file-clear-button" title="Clear file" data-filename="<?php echo e($file_path); ?>"><i class="fa fa-remove"></i></a>
		    	<div class="clearfix"></div>
	    	</div>
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
    <?php endif; ?>
	
	<input
        type="file"
        id="<?php echo e($field['name']); ?>_file_input"
        name="<?php echo e($field['name']); ?>[]"
        value="<?php echo e(old($field['name']) ? old($field['name']) : (isset($field['default']) ? $field['default'] : '' )); ?>"
        <?php echo $__env->make('crud::inc.field_attributes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        multiple
    >

    
    <?php if(isset($field['hint'])): ?>
        <p class="help-block"><?php echo $field['hint']; ?></p>
    <?php endif; ?>
</div>




    <?php $__env->startPush('crud_fields_scripts'); ?>
        <!-- no scripts -->
        <script>
	        $(".file-clear-button").click(function(e) {
	        	e.preventDefault();
	        	var container = $(this).parent().parent();
	        	var parent = $(this).parent();
	        	// remove the filename and button
	        	parent.remove();
	        	// if the file container is empty, remove it
	        	if ($.trim(container.html())=='') {
	        		container.remove();
	        	}
	        	$("<input type='hidden' name='clear_<?php echo e($field['name']); ?>[]' value='"+$(this).data('filename')+"'>").insertAfter("#<?php echo e($field['name']); ?>_file_input");
	        });

	        $("#<?php echo e($field['name']); ?>_file_input").change(function() {
	        	console.log($(this).val());
	        	// remove the hidden input, so that the setXAttribute method is no longer triggered
	        	$(this).next("input[type=hidden]").remove();
	        });
        </script>
    <?php $__env->stopPush(); ?>