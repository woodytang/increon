

<template>

<div class="brand-list">


    <section class="brand-list-item" style="background-image:url('/image/brand1.jpg')" @click='to'>
        <span class="brand-title">Brand Title</span>
    </section>
    <section class="brand-list-item" style="background-image:url('/image/brand2.jpg')"  @click='to'>
        <span class="brand-title dk">Brand Title</span>
    </section>
    <section class="brand-list-item" style="background-image:url('/image/brand3.jpg')"  @click='to'>
        <span class="brand-title">Brand Title</span>
    </section>
    <section class="brand-list-item" style="background-image:url('/image/brand4.jpg')"  @click='to'>
        <span class="brand-title">Brand Title</span>
    </section>

</div>

</template>

<script>

import brand from './brand.vue';


export default {


    ready() {
        console.log('Component ready.')
    },
    components: {
        brand
    },
    methods: {
        to() {

            this.$router.push('brand')
        }
    }

}

</script>
